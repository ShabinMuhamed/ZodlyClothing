<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;


class HomeController extends Controller
{
    public function index()
{
    $featuredProducts = Product::where('is_featured', true)->limit(4)->get();
    $trendingProducts = Product::where('is_trending', true)->limit(4)->get();

    return view('index', compact('featuredProducts', 'trendingProducts'));
}

public function test()
{
    $products = Product::all();
    return view('kaira',compact('products'));
}
}
