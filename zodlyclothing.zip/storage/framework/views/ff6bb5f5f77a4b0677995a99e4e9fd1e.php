

<?php $__env->startSection('content'); ?>

<!-- Hero Banner -->
<div class="hero-banner text-center">
    <div>
        <h1 class="display-4 fw-bold">Welcome to Zodly Clothing</h1>
        <p class="lead">Shop the latest fashion trends</p>
        <a href="#featured" class="btn btn-outline-light btn-lg mt-3">Shop Now</a>
    </div>
</div>

<!-- Featured Products -->
<div class="container py-5" id="featured">
    <h2 class="text-center mb-4">Featured Products</h2>
    <div class="row">
        <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100 shadow-sm border-0">
                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                    <div class="card-body text-center">
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                        <p class="card-text">₹<?php echo e(number_format($product->price)); ?></p>
                        <a href="https://wa.me/91xxxxxxxxxx?text=I'm%20interested%20in%20<?php echo e(urlencode($product->name)); ?>" class="btn btn-success" target="_blank">Buy Now</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- Trending Items -->
<div class="container py-5 bg-light" id="trending">
    <h2 class="text-center mb-4">Trending Items</h2>
    <div class="row">
        <?php $__currentLoopData = $trendingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100 shadow-sm border-0">
                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                    <div class="card-body text-center">
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                        <p class="card-text">₹<?php echo e(number_format($product->price)); ?></p>
                        <a href="https://wa.me/91xxxxxxxxxx?text=I'm%20interested%20in%20<?php echo e(urlencode($product->name)); ?>" class="btn btn-success" target="_blank">Buy Now</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- Newsletter -->
<div class="container py-5 text-center" id="contact">
<img src="<?php echo e(asset('testimages/banner.jpg')); ?>">
    <h4>Subscribe to our newsletter</h4>
    <form class="row justify-content-center mt-3">
        <div class="col-md-4">
            <input type="email" class="form-control" placeholder="Enter your email">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary">Subscribe</button>
        </div>
    </form>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-4">
    <p>&copy; <?php echo e(date('Y')); ?> Zodly Clothing. All rights reserved.</p>
</footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\zodlyclothing\resources\views/index.blade.php ENDPATH**/ ?>