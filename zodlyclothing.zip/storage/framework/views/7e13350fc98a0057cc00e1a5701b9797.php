<footer id="footer" class="mt-5">
  <div class="container">
    <div class="row d-flex flex-wrap justify-content-between py-5">

      <!-- Brand + Social Links -->
      <div class="col-md-3 col-sm-6">
        <div class="footer-menu">
          <div class="footer-intro mb-4">
            <a href="<?php echo e(url('/')); ?>">
              <img src="<?php echo e(asset('images/main-logo.png')); ?>" alt="logo">
            </a>
          </div>
          <p>Your trusted destination for quality t-shirts. Reach out to us on WhatsApp for orders.</p>
          <div class="social-links mt-3">
            <ul class="list-unstyled d-flex flex-wrap gap-3">
              <li><a href="#" class="text-secondary"><i class="fab fa-facebook-f"></i></a></li>
              <li><a href="https://www.instagram.com/yourbrand/" class="text-secondary" target="_blank"><i class="fab fa-instagram"></i></a></li>
              <li><a href="https://wa.me/919000000000" class="text-secondary" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
            </ul>
          </div>
          <!-- Instagram Button -->
          <div class="mt-3">
            <a href="https://www.instagram.com/yourbrand/" target="_blank" class="btn btn-dark btn-sm px-4">
              <i class="fab fa-instagram me-2"></i> Follow us on Instagram
            </a>
          </div>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="col-md-3 col-sm-6">
        <h5 class="widget-title text-uppercase mb-4">Quick Links</h5>
        <ul class="list-unstyled text-uppercase fs-6">
          <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
          <li><a href="<?php echo e(url('/products')); ?>">Shop</a></li>
          <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
        </ul>
      </div>

      <!-- Support -->
      <div class="col-md-3 col-sm-6">
        <h5 class="widget-title text-uppercase mb-4">Support</h5>
        <ul class="list-unstyled text-uppercase fs-6">
          <li><a href="#">Order Help</a></li>
          <li><a href="#">Shipping Info</a></li>
          <li><a href="#">Privacy Policy</a></li>
        </ul>
      </div>

      <!-- Contact + Newsletter -->
      <div class="col-md-3 col-sm-6">
        <h5 class="widget-title text-uppercase mb-4">Contact</h5>
        <p>Email: <a href="mailto:support@yourbrand.com">support@yourbrand.com</a></p>
        <p>WhatsApp: <a href="https://wa.me/919000000000" target="_blank">+91 90000 00000</a></p>

        <!-- Newsletter Signup -->
        <h5 class="widget-title text-uppercase mt-4 mb-3">Newsletter</h5>
        <p class="mb-2">Sign up for updates and offers.</p>
        <form id="form" class="d-flex flex-column gap-2">
          <input type="text" name="email" placeholder="Your Email Address" class="form-control form-control-sm">
          <button class="btn btn-dark btn-sm text-uppercase">Sign Up</button>
        </form>
      </div>

    </div>
  </div>

  <!-- Bottom Bar -->
  <div class="border-top py-4 text-center">
    <div class="container">
      <p class="mb-0">© <?php echo e(date('Y')); ?> ZodlyClothing. All rights reserved.</p>
    </div>
  </div>
</footer>
<?php /**PATH C:\Users\DELL\Desktop\New folder\zodlyclothing\resources\views/footer.blade.php ENDPATH**/ ?>