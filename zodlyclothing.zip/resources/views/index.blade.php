@extends('layouts.app')

@section('content')

<!-- Hero Banner -->
<div class="hero-banner text-center">
    <div>
        <h1 class="display-4 fw-bold">Welcome to Zodly Clothing</h1>
        <p class="lead">Shop the latest fashion trends</p>
        <a href="#featured" class="btn btn-outline-light btn-lg mt-3">Shop Now</a>
    </div>
</div>

<!-- Featured Products -->
<div class="container py-5" id="featured">
    <h2 class="text-center mb-4">Featured Products</h2>
    <div class="row">
        @foreach($featuredProducts as $product)
            <div class="col-md-3 mb-4">
                <div class="card h-100 shadow-sm border-0">
                    <img src="{{ asset('storage/' . $product->image) }}" class="card-img-top" alt="{{ $product->name }}">
                    <div class="card-body text-center">
                        <h5 class="card-title">{{ $product->name }}</h5>
                        <p class="card-text">₹{{ number_format($product->price) }}</p>
                        <a href="https://wa.me/91xxxxxxxxxx?text=I'm%20interested%20in%20{{ urlencode($product->name) }}" class="btn btn-success" target="_blank">Buy Now</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<!-- Trending Items -->
<div class="container py-5 bg-light" id="trending">
    <h2 class="text-center mb-4">Trending Items</h2>
    <div class="row">
        @foreach($trendingProducts as $product)
            <div class="col-md-3 mb-4">
                <div class="card h-100 shadow-sm border-0">
                    <img src="{{ asset('storage/' . $product->image) }}" class="card-img-top" alt="{{ $product->name }}">
                    <div class="card-body text-center">
                        <h5 class="card-title">{{ $product->name }}</h5>
                        <p class="card-text">₹{{ number_format($product->price) }}</p>
                        <a href="https://wa.me/91xxxxxxxxxx?text=I'm%20interested%20in%20{{ urlencode($product->name) }}" class="btn btn-success" target="_blank">Buy Now</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<!-- Newsletter -->
<div class="container py-5 text-center" id="contact">
<img src="{{ asset('testimages/banner.j') }}">
    <h4>Subscribe to our newsletter</h4>
    <form class="row justify-content-center mt-3">
        <div class="col-md-4">
            <input type="email" class="form-control" placeholder="Enter your email">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary">Subscribe</button>
        </div>
    </form>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-4">
    <p>&copy; {{ date('Y') }} Zodly Clothing. All rights reserved.</p>
</footer>

@endsection
