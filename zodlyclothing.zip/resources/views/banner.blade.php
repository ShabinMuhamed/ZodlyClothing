<section id="billboard" class="position-relative">
  <img src="{{ asset('images/video-image.jpg') }}" alt="New Collection Banner" class="img-fluid w-100">

  <!-- Text Overlay -->
  <div class="position-absolute top-50 start-50 translate-middle text-center text-white">
    <h1 class="display-4 fw-bold text-uppercase" data-aos="fade-up">New Collection</h1>
    <p class="lead" data-aos="fade-up" data-aos-delay="200">Explore our latest arrivals in style</p>
    <a href="{{ url('/products') }}" class="btn btn-dark mt-3 text-uppercase px-4 py-2" data-aos="fade-up" data-aos-delay="400">Shop Now</a>
  </div>
</section>
